<?php
declare(strict_types=1);

function jsonOut($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

require_once __DIR__ . '/src/Util/Store.php';
require_once __DIR__ . '/src/Util/Merge.php';
require_once __DIR__ . '/src/Parser/ManualCsv.php';
require_once __DIR__ . '/src/Scraper/LescoScraper.php';

use LESCO\Util\Store;
use LESCO\Util\Merge;
use LESCO\Parser\ManualCsv;
use LESCO\Scraper\LescoScraper;

$storageDir = __DIR__ . '/storage';
$store = new Store($storageDir);
$route = $_GET['route'] ?? 'schedule';

try {
switch ($route) {

  case 'config':
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
      jsonOut($store->readConfig());
    } else {
      $raw = file_get_contents('php://input') ?: '';
      $payload = null;
      if (trim($raw) !== '') {
        $payload = json_decode($raw, true);
        if ($payload === null && json_last_error() !== JSON_ERROR_NONE) {
          jsonOut(['ok'=>false,'error'=>'Invalid JSON','detail'=>json_last_error_msg(),'raw'=>$raw],400);
        }
      }
      if (!is_array($payload)) $payload = $store->readConfig();
      $store->writeConfig($payload);
      jsonOut(['ok'=>true,'saved'=>true]);
    }
    break;

  case 'ingest':
    $scraper = new LescoScraper();
    $official = $scraper->fetch();
    $manual = (new ManualCsv($storageDir . '/manual.csv'))->read();
    $merged = Merge::merge($official, $manual);
    $store->writeSchedule($merged);
    jsonOut(['ok'=>true,'count'=>count($merged)]);
    break;

  case 'probe':
    $scraper = new LescoScraper();
    $sample = array_slice($scraper->fetch(), 0, 5);
    jsonOut(['ok'=>true,'sample'=>$sample]);
    break;

  case 'schedule':
  default:
    $data = $store->readSchedule();
    $items = $data['items'] ?? [];
    $q = strtolower(trim($_GET['q'] ?? ''));
    $area = strtolower(trim($_GET['area'] ?? ''));
    $feeder = strtolower(trim($_GET['feeder'] ?? ''));
    $date = $_GET['date'] ?? null;
    $dayStart = $date ? strtotime($date . ' 00:00:00') : null;
    $dayEnd = $date ? strtotime($date . ' 23:59:59') : null;

    $filtered = array_values(array_filter($items, function ($it)
        use ($q, $area, $feeder, $dayStart, $dayEnd) {
      $hay = strtolower(($it['area'] ?? '') . ' ' . ($it['feeder'] ?? '') . ' ' . ($it['reason'] ?? ''));
      if ($q && strpos($hay, $q) === false) return false;
      if ($area && strpos(strtolower($it['area'] ?? ''), $area) === false) return false;
      if ($feeder && strpos(strtolower($it['feeder'] ?? ''), $feeder) === false) return false;
      if ($dayStart && !empty($it['start'])) {
        $t = strtotime($it['start']);
        if (!($t >= $dayStart && $t <= $dayEnd)) return false;
      }
      return true;
    }));

    jsonOut(['ok'=>true,'updatedAt'=>$data['updatedAt'] ?? null,'count'=>count($filtered),'items'=>$filtered]);
}

} catch (Throwable $e) {
  jsonOut(['ok'=>false,'error'=>$e->getMessage(),'trace'=>$e->getFile().':'.$e->getLine()],500);
}
