<?php
require_once __DIR__ . '/src/Util/Store.php';
use SHUTDOWN\Util\Store;
$store = new Store(__DIR__ . DIRECTORY_SEPARATOR . 'storage');
$meta = $store->meta();
$cfg = $store->readConfig();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin — Shutdown</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">Shutdown</a>
    <span class="navbar-text">Admin</span>
  </div>
</nav>
<main class="container py-4">
  <div class="row g-3">
    <div class="col-lg-8">
      <div class="card"><div class="card-body">
        <h5 class="card-title">Data Controls</h5>
        <p class="text-muted small">Last updated: <b><?php echo htmlspecialchars($meta['mtime'] ?? '—') ?></b>, size <?php echo (int)($meta['size'] ?? 0) ?> bytes</p>
        <div class="d-flex flex-wrap gap-2">
          <button id="btnIngest" class="btn btn-primary">Fetch Latest Now</button>
          <button id="btnProbe" class="btn btn-outline-secondary">Probe Sources</button>
          <a class="btn btn-outline-dark" href="api.php?route=backup">Backup Storage (ZIP)</a>
          <a class="btn btn-outline-dark" href="../storage/schedule.json" target="_blank">Download JSON</a>
        </div>
        <div id="ingestOut" class="mt-3 small text-monospace"></div>
      </div></div>

      <div class="card mt-3"><div class="card-body">
        <h5 class="card-title">Config (Sources)</h5>
        <form id="cfgForm" class="row g-2">
          <div class="col-12"><label class="form-label">Config JSON</label>
            <textarea id="cfg" class="form-control" rows="8"><?php echo htmlspecialchars(json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)) ?></textarea>
          </div>
          <div class="col-12"><button class="btn btn-success">Save Config</button></div>
        </form>
        <div id="cfgOut" class="small mt-2"></div>
      </div></div>

      <div class="card mt-3"><div class="card-body">
        <h5 class="card-title">Add Single Entry</h5>
        <form id="addForm" class="row g-2">
          <div class="col-md-4"><input class="form-control" name="area" placeholder="Area" required></div>
          <div class="col-md-4"><input class="form-control" name="feeder" placeholder="Feeder" required></div>
          <div class="col-md-4"><input class="form-control" name="type" placeholder="Type" value="scheduled"></div>
          <div class="col-md-6"><input class="form-control" name="start" placeholder="Start ISO (YYYY-MM-DDTHH:MM:SS+05:00)" required></div>
          <div class="col-md-6"><input class="form-control" name="end" placeholder="End ISO (YYYY-MM-DDTHH:MM:SS+05:00)"></div>
          <div class="col-12"><input class="form-control" name="reason" placeholder="Reason"></div>
          <div class="col-12"><button class="btn btn-success">Append to Manual</button></div>
        </form>
        <div id="addOut" class="small mt-2"></div>
      </div></div>

      <div class="card mt-3"><div class="card-body">
        <h5 class="card-title">Manual CSV Upload</h5>
        <form method="post" action="admin_upload.php" enctype="multipart/form-data">
          <p class="small text-muted">Headers: <code>utility,area,feeder,start,end,type,reason,source,url,confidence</code></p>
          <input type="file" name="csv" accept=".csv" class="form-control">
          <button class="btn btn-dark mt-2">Upload</button>
        </form>
      </div></div>
    </div>

    <div class="col-lg-4">
      <div class="card"><div class="card-body">
        <h5 class="card-title">History & Changes</h5>
        <div class="input-group input-group-sm mb-2">
          <span class="input-group-text">Day</span>
          <input id="histDay" type="date" class="form-control">
          <button id="btnHistory" class="btn btn-outline-secondary">View</button>
        </div>
        <pre id="histOut" class="small"></pre>
        <button id="btnChanges" class="btn btn-sm btn-outline-secondary">Show Change Log</button>
        <pre id="changesOut" class="small mt-2"></pre>
      </div></div>
    </div>
  </div>
</main>
<script>const API_BASE='api.php';</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/admin.js"></script>
</body>
</html>
