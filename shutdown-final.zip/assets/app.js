async function fetchJSON(url){ const r=await fetch(url); return r.json(); }
async function fetchSchedule(params={}){
  const qs = new URLSearchParams(params);
  return fetchJSON(`${API_BASE}?route=schedule&${qs.toString()}`);
}
async function fetchDivisions(){ const j=await fetchJSON(`${API_BASE}?route=divisions`); return j.divisions||[]; }
function fmt(iso){ if(!iso) return '—'; const d=new Date(iso); return d.toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'}); }
function groupBy(items, keyFn){
  const m = new Map();
  for (const it of items){ const k=keyFn(it); if(!m.has(k)) m.set(k, []); m.get(k).push(it); }
  return m;
}
function renderTable(items){
  return `<table class="table table-sm align-middle">
    <thead><tr><th>Area</th><th>Feeder</th><th>Start</th><th>End</th><th>Type</th><th>Reason</th></tr></thead>
    <tbody>
      ${items.map(it=>`
        <tr>
          <td>${it.area||'—'}</td>
          <td class="text-muted">${it.feeder||'—'}</td>
          <td>${fmt(it.start)}</td>
          <td>${fmt(it.end)}</td>
          <td><span class="badge bg-${badge(it.type)}">${it.type||'scheduled'}</span></td>
          <td class="text-muted">${it.reason||''}</td>
        </tr>`).join('')}
    </tbody></table>`;
}
function badge(t){ const tt=(t||'scheduled').toLowerCase(); if(tt.includes('force')) return 'danger'; if(tt.includes('maint')) return 'warning'; return 'info'; }
function paginate(arr, page=1, per=30){ const start=(page-1)*per; return arr.slice(start,start+per); }
function pager(total, page, per){
  const pages=Math.max(1, Math.ceil(total/per));
  let html=''; for(let i=1;i<=pages;i++){ html+=`<li class="page-item ${i===page?'active':''}"><a class="page-link" data-page="${i}">${i}</a></li>`; }
  return html;
}
let currentItems=[], currentPage=1, perPage=30;
function render(items, updatedAt){
  currentItems = items;
  currentPage = 1;
  draw();
  document.getElementById('meta').textContent = `Updated: ${updatedAt ? new Date(updatedAt).toLocaleString() : '—'} • ${items.length} result(s)`;
}
function draw(){
  const pageItems = paginate(currentItems, currentPage, perPage);
  const byDate = groupBy(pageItems, it => (it.start||'').slice(0,10));
  const container = document.getElementById('grouped'); container.innerHTML='';
  for (const [date, arr] of byDate){
    const block = document.createElement('div'); block.className='grp';
    const h = document.createElement('div'); h.className='thead'; h.textContent = date || 'No date';
    block.appendChild(h);
    block.innerHTML += renderTable(arr);
    container.appendChild(block);
  }
  document.getElementById('pager').innerHTML = pager(currentItems.length, currentPage, perPage);
  document.querySelectorAll('#pager .page-link').forEach(a=>a.addEventListener('click', e=>{
    currentPage = parseInt(e.target.getAttribute('data-page'),10); draw();
  }));
}
async function go(){
  const q=document.getElementById('q').value;
  const area=document.getElementById('area').value;
  const feeder=document.getElementById('feeder').value;
  const date=document.getElementById('date').value;
  const division=document.getElementById('division').value;
  const {items, updatedAt} = await fetchSchedule({q, area, feeder, date, division});
  render(items, updatedAt);
}
async function initDivisions(){
  const divs = await fetchDivisions();
  const sel=document.getElementById('division');
  divs.forEach(d=>{ const opt=document.createElement('option'); opt.value=d; opt.textContent=d; sel.appendChild(opt); });
}
document.getElementById('searchBtn').addEventListener('click', go);
window.addEventListener('DOMContentLoaded', ()=>{ initDivisions().then(go); });
