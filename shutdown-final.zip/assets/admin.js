// assets/admin.js
async function call(route, opts = {}) {
  const res = await fetch(`api.php?route=${route}`, opts);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`HTTP ${res.status} ${res.statusText}\n\n${text}`);
  }
}

document.getElementById('btnIngest').addEventListener('click', async () => {
  const out = document.getElementById('ingestOut');
  out.textContent = 'Fetching…';
  try {
    const data = await call('ingest');
    out.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    out.textContent = String(e);
  }
});

document.getElementById('btnProbe').addEventListener('click', async () => {
  const out = document.getElementById('ingestOut');
  out.textContent = 'Probing…';
  try {
    const data = await call('probe');
    out.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    out.textContent = String(e);
  }
});

document.getElementById('cfgForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const out = document.getElementById('cfgOut');
  const textarea = document.getElementById('cfg');
  const jsonStr = textarea.value.trim();

  try {
    JSON.parse(jsonStr);
  } catch (err) {
    out.textContent = 'Invalid JSON: ' + err.message;
    return;
  }

  try {
    const res = await fetch('api.php?route=config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: jsonStr
    });
    const text = await res.text();
    try {
      const j = JSON.parse(text);
      out.textContent = JSON.stringify(j, null, 2);
    } catch {
      out.textContent = `Server returned non-JSON (HTTP ${res.status}). Body:\n${text}`;
    }
  } catch (err) {
    out.textContent = 'Request failed: ' + err.message;
  }
});

document.getElementById('addForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const out = document.getElementById('addOut');
  const payload = Object.fromEntries(new FormData(e.target).entries());
  try {
    const res = await fetch('api.php?route=addManual', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const text = await res.text();
    try {
      out.textContent = JSON.stringify(JSON.parse(text), null, 2);
    } catch {
      out.textContent = `Server returned non-JSON (HTTP ${res.status}). Body:\n${text}`;
    }
    e.target.reset();
  } catch (err) {
    out.textContent = 'Request failed: ' + err.message;
  }
});
