# Shutdown (LESCO) — Complete PHP Service (Filesystem, Apache-Ready)

**Highlights**
- **Retains history**: writes daily snapshots to `storage/history/YYYY-MM-DD.json` + `storage/changelog.ndjson`
- **Professional UI**: Bootstrap 5, grouped tables, pagination, map with overlays
- **Admin console**: ingest/probe, CSV upload, single-entry add, **source toggles**, **backup/export ZIP**, download JSON
- **Feeds & Exports**: division feeds (RSS/JSON), CSV/ICS/PDF export
- **Config**: `storage/config.json` to enable/disable sources

## Quick Start
1) Upload to Apache/PHP 8.1+.
2) Make `storage/` writable by PHP.
3) Open `/public/admin.php` → Configure sources → **Fetch Latest Now**.
4) Use `/public/index.php` (Search, Map) and `/public/sources.php` (status).
5) Set cron: `php cron/ingest.php` every 10–15 minutes.

## Sources (toggle in config.json)
- **official**: LESCO shutdown table (HTML)
- **facebook**: PR LESCO page parser (simple HTML text scrape; optional)
- **ccms**: PITC CCMS placeholder (off by default)
- **manual**: local CSV overrides

You can add more URLs to `storage/config.json` without code changes.
