<?php
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Shutdown Lookup</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">Shutdown</a>
    <div class="navbar-nav">
      <a class="nav-link active" href="index.php">Home</a>
      <a class="nav-link" href="sources.php">Sources</a>
      <a class="nav-link" href="admin.php">Admin</a>
    </div>
  </div>
</nav>
<main class="container py-4">
  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#search" type="button">Search</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#maptab" type="button">Map</button></li>
  </ul>
  <div class="tab-content p-3 border border-top-0 rounded-bottom bg-white">
    <div class="tab-pane fade show active" id="search">
      <div class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label">Search</label><input id="q" class="form-control" placeholder="Area/Feeder/Reason"></div>
        <div class="col-md-2"><label class="form-label">Area</label><input id="area" class="form-control" placeholder="Area"></div>
        <div class="col-md-2"><label class="form-label">Feeder</label><input id="feeder" class="form-control" placeholder="Feeder"></div>
        <div class="col-md-2"><label class="form-label">Date</label><input id="date" type="date" class="form-control"></div>
        <div class="col-md-2"><label class="form-label">Division</label><select id="division" class="form-select"><option value="">All</option></select></div>
        <div class="col-md-1 d-grid"><button id="searchBtn" class="btn btn-primary">Go</button></div>
      </div>
      <div class="d-flex flex-wrap gap-2 mt-2">
        <button id="btnCsv" class="btn btn-outline-secondary btn-sm">CSV</button>
        <button id="btnIcs" class="btn btn-outline-secondary btn-sm">ICS</button>
        <button id="btnPdf" class="btn btn-outline-dark btn-sm">PDF</button>
      </div>
      <div id="meta" class="text-muted small mt-3"></div>
      <div id="grouped" class="mt-3"></div>
      <nav><ul class="pagination mt-3" id="pager"></ul></nav>
    </div>
    <div class="tab-pane fade" id="maptab">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="text-muted small" id="mapMeta"></div>
        <div><button class="btn btn-sm btn-outline-secondary" id="refreshMap">Refresh</button></div>
      </div>
      <div id="map" style="height:520px;border-radius:12px;overflow:hidden"></div>
      <div class="small text-muted mt-2">Polygons show area boundaries (approx). Colors: <span class="badge bg-info">Scheduled</span> <span class="badge bg-warning text-dark">Maintenance</span> <span class="badge bg-danger">Forced</span>.</div>
    </div>
  </div>
</main>
<script>const API_BASE='api.php';</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="assets/app.js"></script>
<script src="assets/export.js"></script>
<script src="assets/map.js"></script>
</body>
</html>
