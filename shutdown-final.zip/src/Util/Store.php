<?php
namespace SHUTDOWN\Util;
class Store {
  private string $dir;
  private string $schedulePath;
  private string $logPath;
  private string $historyDir;
  private string $changelogPath;
  private string $configPath;
  public function __construct(string $dir){
    $this->dir = $dir;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $this->schedulePath = $dir . DIRECTORY_SEPARATOR . 'schedule.json';
    $this->logPath = $dir . DIRECTORY_SEPARATOR . 'sources.log';
    $this->historyDir = $dir . DIRECTORY_SEPARATOR . 'history';
    $this->changelogPath = $dir . DIRECTORY_SEPARATOR . 'changelog.ndjson';
    $this->configPath = $dir . DIRECTORY_SEPARATOR . 'config.json';
    if (!is_dir($this->historyDir)) @mkdir($this->historyDir, 0775, true);
    if (!file_exists($this->schedulePath)) {
      file_put_contents($this->schedulePath, json_encode(['updatedAt'=>null, 'items'=>[]], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    }
    if (!file_exists($this->configPath)) {
      $default = [
  'timezone' => 'Asia/Karachi',
  'sources' => [
    'official' => ['enabled' => true, 'url' => 'https://www.lesco.gov.pk/LoadSheddingShutdownSchedule'],
    'facebook' => ['enabled' => false, 'url' => 'https://www.facebook.com/PRLESCO/'],
    'ccms'     => ['enabled' => false, 'url' => 'https://ccms.pitc.com.pk/FeederDetails'],
    'manual'   => ['enabled' => true]
  ]
];
      file_put_contents($this->configPath, json_encode($default, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    }
  }
  public function readConfig(): array {
    $txt = @file_get_contents($this->configPath);
    return $txt ? json_decode($txt, true) : [];
  }
  public function writeConfig(array $cfg): void {
    file_put_contents($this->configPath, json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  }
  public function readSchedule(): array {
    $json = @file_get_contents($this->schedulePath);
    return $json ? json_decode($json, true) : ['updatedAt'=>null,'items'=>[]];
  }
  private function keyOf(array $it): string {
    return strtolower(($it['feeder'] ?? '')).'|'.($it['start'] ?? '').'|'.($it['end'] ?? '');
  }
  public function writeSchedule(array $items): void {
    $prev = $this->readSchedule();
    $oldItems = $prev['items'] ?? [];
    $payload = ['updatedAt' => gmdate('c'), 'items' => $items];
    // atomic write
    $tmp = $this->schedulePath . '.tmp';
    $fp = fopen($tmp, 'c+');
    if ($fp === false) throw new \RuntimeException('Cannot open temp file');
    if (!flock($fp, LOCK_EX)) throw new \RuntimeException('Cannot lock temp file');
    ftruncate($fp, 0);
    fwrite($fp, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    rename($tmp, $this->schedulePath);
    // history (day file)
    $day = (new \DateTime('now', new \DateTimeZone('UTC')))->format('Y-m-d');
    $dayPath = $this->historyDir . DIRECTORY_SEPARATOR . $day . '.json';
    $existing = [];
    if (file_exists($dayPath)) {
      $existing = json_decode(file_get_contents($dayPath), true) ?: [];
    }
    $map = [];
    foreach ($existing as $ex) { $map[$this->keyOf($ex)] = $ex; }
    foreach ($items as $it) { $map[$this->keyOf($it)] = $it; }
    file_put_contents($dayPath, json_encode(array_values($map), JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    // changelog
    $added = 0; $removed = 0;
    $oldMap = []; foreach ($oldItems as $o) { $oldMap[$this->keyOf($o)] = true; }
    $newMap = []; foreach ($items as $n) { $newMap[$this->keyOf($n)] = true; }
    foreach ($newMap as $k => $_) if (!isset($oldMap[$k])) $added++;
    foreach ($oldMap as $k => $_) if (!isset($newMap[$k])) $removed++;
    file_put_contents($this->changelogPath, json_encode(['ts'=>gmdate('c'),'added'=>$added,'removed'=>$removed])."\n", FILE_APPEND);
  }
  public function backupZip(string $destPath): void {
    $zip = new \ZipArchive();
    if ($zip->open($destPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
      throw new \RuntimeException('Cannot open zip');
    }
    $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($this->dir));
    foreach ($it as $file) {
      if ($file->isDir()) continue;
      $real = $file->getRealPath();
      $rel = substr($real, strlen($this->dir) + 1);
      $zip->addFile($real, $rel);
    }
    $zip->close();
  }
  public function meta(): array {
    $st = @stat($this->schedulePath);
    return ['path'=>$this->schedulePath, 'size'=>$st ? $st['size'] : 0, 'mtime'=>$st ? date('c', $st['mtime']) : null];
  }
}
