<?php
namespace SHUTDOWN\Util;
class Merge {
  public static function normalize(array $it): array {
    return [
      'utility' => $it['utility'] ?? 'LESCO',
      'area' => trim($it['area'] ?? ''),
      'feeder' => trim($it['feeder'] ?? ''),
      'start' => isset($it['start']) && $it['start'] ? date('c', strtotime($it['start'])) : null,
      'end' => isset($it['end']) && $it['end'] ? date('c', strtotime($it['end'])) : null,
      'type' => $it['type'] ?? 'scheduled',
      'reason' => $it['reason'] ?? '',
      'source' => $it['source'] ?? '',
      'url' => $it['url'] ?? '',
      'confidence' => isset($it['confidence']) ? floatval($it['confidence']) : 0.7,
    ];
  }
  public static function merge(array $arrays): array {
    $all = [];
    foreach ($arrays as $arr) foreach ($arr as $x) $all[] = self::normalize($x);
    $map = [];
    foreach ($all as $it) {
      $key = strtolower(($it['feeder'] ?? '')) . '|' . ($it['start'] ?? '') . '|' . ($it['end'] ?? '');
      if (!isset($map[$key]) || $it['confidence'] > $map[$key]['confidence']) $map[$key] = $it;
    }
    $arr = array_values($map);
    usort($arr, function($x,$y){ return strcmp($x['start'] ?? '', $y['start'] ?? ''); });
    return $arr;
  }
}
