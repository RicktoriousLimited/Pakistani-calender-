<?php
namespace SHUTDOWN\Parser;
class ManualCsv {
  private string $path;
  public function __construct(string $path){ $this->path = $path; }
  public function read(): array {
    if (!file_exists($this->path)) return [];
    $fh = fopen($this->path, 'r');
    if (!$fh) return [];
    $headers = fgetcsv($fh);
    if (!$headers) return [];
    $rows = [];
    while (($row = fgetcsv($fh)) !== false) {
      if (count($row) === 1 && $row[0] === null) continue;
      $rows[] = array_combine($headers, $row);
    }
    fclose($fh);
    return array_map(function($r){
      return [
        'utility' => $r['utility'] ?? 'LESCO',
        'area' => $r['area'] ?? '',
        'feeder' => $r['feeder'] ?? '',
        'start' => $r['start'] ?? '',
        'end' => $r['end'] ?? '',
        'type' => $r['type'] ?? 'scheduled',
        'reason' => $r['reason'] ?? '',
        'source' => $r['source'] ?? 'manual',
        'url' => $r['url'] ?? '',
        'confidence' => isset($r['confidence']) ? floatval($r['confidence']) : 0.8,
      ];
    }, $rows);
  }
}
